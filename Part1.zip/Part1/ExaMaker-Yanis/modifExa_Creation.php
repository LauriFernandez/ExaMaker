
<?php
/*
 * modifExa.php
 * 
 * Copyright 2016 Yanis Kacher <kacher.yanis@gmail.com>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 * 
 */


session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">

<head>
	<link rel="icon" href="images/exaMaker.png">
	<link rel="stylesheet" href="../ExaMaker-Loic/cree2.css" />
	<title>ExaMaker - Modification</title>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />

    
</head>

<header>
		<h1>Examen > Exercice</h1>
	</header>
	
<body>
	 
  
  <script>
var form = document.getElementById("form-id");

document.getElementById("form-id").addEventListener("click", function () {
	form.action(\'modifExo.php\');
  form.submit();
  
});
</script>



<?php

for($a=1;$a<=$_SESSION['cptexo'];$a++){
	/*echo '<div id="Exercice"> <p>- Exercice '.$n.': '.$exos['Nom'].' ('.$exos['Points'].' points)</p>
	<form action=\'modifExo.php\' method=\'post\'>
	<div id="Button">
	<input style="background-color: #3bb39d" type="submit" name=\''.$exos['ID'].'\' value="Modifier">
	<input style="background-color: #e2574c" type="submit" name=\''.$exos['ID'].'\' value="Supprimer">
	</div>
	</form>
	</div>*/
	
	echo '<div id="Examen">
  <h2>Exercice '.$a.'</h2>';
	
							echo"<form action='modifExo_Cration.php' method='post'>";
								for($b=1;$b<=$_SESSION['nbQuestion'][$a];$b++)
							{					
						
									//LETS GO
									
									echo '<div class="Question">
						<div class="Barre">
						<h3>'.@$_SESSION["ex".$a]["bareme"][$b].'</h3>
							<p>Question '.@$_SESSION["ex".$a]["num"][$b].' </p>
						<p>'.$_SESSION['titreExo'][$a].'</p>
						
						
						<div id="SVG">
						<a href="../Question.php?numExercice='.$_GET["numExercice"].'+numQuestion='.$b.'" class="svg"><object type="image/svg+xml" data="list.svg" width="36" ></object></a>
						<a href="../supprimerExa.php?Supprimer='.$b.'" class="svg"><object type="image/svg+xml" data="cancel.svg" width="36" ></object></a>
						
						</div>
						</div>
						<div class="Ennonce">
						<p>'.@$_SESSION["ex".$a]["question"][$b].'</p>
						
							</div>';
	
								
															
							}
							echo"</form>";

	
	}
	
	
	echo '<a href="../Question.php?numExercice='.$_GET["numExercice"].'" class="svg">cree nouvel exercice<object type="image/svg+xml" data="list.svg" width="36" ></object></a>';
	
	echo '<a href="../Exercice.php" class="svg">retour choix examen<object type="image/svg+xml" data="cancel.svg" width="36" ></object></a>';	
?>

	
</body>

</html>
