
1.Ouvrez modifExa.php

2.Enjoy!

/*
Les fonctionnalitées ne sont pas encore active tel que 
ajouter/modifier et supprimer une question ou un exercice
*/
