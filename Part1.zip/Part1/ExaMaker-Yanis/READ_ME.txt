   ,ggggggg,                          ,ggg, ,ggg,_,ggg,                                                 
 ,dP""""""Y8b                        dP""Y8dP""Y88P""Y8b              ,dPYb,                            
 d8'    a  Y8                        Yb, `88'  `88'  `88              IP'`Yb                            
 88     "Y8P'                         `"  88    88    88              I8  8I                            
 `8baaaa                                  88    88    88              I8  8bgg,                         
,d8P""""         ,gg,   ,gg   ,gggg,gg    88    88    88    ,gggg,gg  I8 dP" "8   ,ggg,    ,gggggg,     
d8"             d8""8b,dP"   dP"  "Y8I    88    88    88   dP"  "Y8I  I8d8bggP"  i8" "8i   dP""""8I     
Y8,            dP   ,88"    i8'    ,8I    88    88    88  i8'    ,8I  I8P' "Yb,  I8, ,8I  ,8'    8I     
`Yba,,_____, ,dP  ,dP"Y8,  ,d8,   ,d8b,   88    88    Y8,,d8,   ,d8b,,d8    `Yb, `YbadP' ,dP     Y8,    
  `"Y8888888 8"  dP"   "Y88P"Y8888P"`Y8   88    88    `Y8P"Y8888P"`Y888P      Y8888P"Y8888P      `Y8    
                                                                                                        
                                                                                                        
                                                                                          
                                                                                                        
 aaaaaaaa                                                                                               
 """"""""                                                                                               
                                         
                                                                                                        
                                                                                                        
 ,ggg, ,ggg,_,ggg,                                            ,ggggggg,                                 
dP""Y8dP""Y88P""Y8b                       8I        ,dPYb,  ,dP""""""Y8b                                
Yb, `88'  `88'  `88                       8I        IP'`Yb  d8'    a  Y8                                
 `"  88    88    88                       8I   gg   I8  8I  88     "Y8P'                                
     88    88    88                       8I   ""   I8  8'  `8baaaa                                     
     88    88    88    ,ggggg,      ,gggg,8I   gg   I8 dP  ,d8P""""         ,gg,   ,gg   ,gggg,gg       
     88    88    88   dP"  "Y8ggg  dP"  "Y8I   88   I8dP   d8"             d8""8b,dP"   dP"  "Y8I       
     88    88    88  i8'    ,8I   i8'    ,8I   88   I8P    Y8,            dP   ,88"    i8'    ,8I       
     88    88    Y8,,d8,   ,d8'  ,d8,   ,d8b,_,88,_,d8b,_  `Yba,,_____, ,dP  ,dP"Y8,  ,d8,   ,d8b,      
     88    88    `Y8P"Y8888P"    P"Y8888P"`Y88P""Y8PI8"8888  `"Y8888888 8"  dP"   "Y88P"Y8888P"`Y8      
                                                    I8 `8,                                              
                                                    I8  `8,                                             
                                                    I8   8I                                             
                                                    I8   8I                                             
                                                    I8, ,8'                                             
                                                     "Y8P'                                                       
                                                                                         
                                              

1.Ouvrez modifExa.php
2.Enjoy!

/*
Les fonctionnalit�es ne sont pas encore active tel que 
ajouter/modifier et supprimer une question ou un exercice
*/