<?php session_start() ?>
<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" href="../cree.css"/>
	<title>Chargement fichier</title>
</head>

<body>
	<header>
		<h1>Chargement du fichier</h1> 
	</header>
	
	<div id="sav">
	<form enctype="multipart/form-data" action="verif_exam.php" method="post">
      <input type="hidden" name="MAX_FILE_SIZE" value="100000" />
     <p id="sav"> Charger l'examen : </p><input  type="file" name="fichier" value="charger" />
	 <br/><br/>
      <input class="validation" type="submit"  name="charger" value="charger" />
	 
    </form>
	
	<br/><a href="../index.html" class="notif">Cliquez sur ce message pour revenir à la page d'accueil</p><br/>
	
	</div>
	
		
	
	
    
</body>
</html>
