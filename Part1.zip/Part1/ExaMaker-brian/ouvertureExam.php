<?php session_start(); ?>
<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" href="../cree.css"/>
	<title>Chargement fichier</title>
</head>

<body>
	<header>
		<h1>Lecture du sujet</h1> 
	</header>
	<div id="sav">
	
	<?php
		
		$f="upload/test.exam";
		$tabFi=file($f);
		$cpt=0;
		$_SESSION['contenu']=array();
		for($i = 0; $i < count($tabFi); $i++)
		{
				
			
			if(preg_match("#^\[#",$tabFi[$i]))
			{
				$tabFi[$i] = str_replace("[","",$tabFi[$i]);
				$tabFi[$i] = str_replace("]","",$tabFi[$i]);
			}
			
			$_SESSION['contenu'][$i]=$tabFi[$i];
			
			$cpt++;
		}
		
		$_SESSION['cpt']=$cpt;

		echo "Voici la forme du sujet: <br/>";
		echo "(Les caracteres ~ et # ne seront pas affichés sur la copie du candidat)<br/><br/>";
		
		for($b=0;$b<$_SESSION['cpt']+2;$b++)
		{		
			echo @$_SESSION['contenu'][$b].'<br/>';
		}
		
		//require('../detailExo.php');
		
		echo "<br/>";
		echo "<a href=\"../connexionS.php?startExam=true\"><button class=\"validation\"> valider et ouvrir l'examen ? </button></a>  <tr/>  <a href=\"../index.html\"><button class=\"validation\"> revenir à la page d'accueil </button></a>";
		echo "<a href=\"../compo.php\"><button class=\"validation\"> composer(test) </button></a>";
					
	?>
	</div>
	
    

	
    
</body>
</html>