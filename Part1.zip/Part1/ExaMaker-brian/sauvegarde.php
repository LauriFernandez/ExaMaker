<?php session_start() ?>
<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" href="../ExaMaker-Loic/sauvegarde.css"/>
	<title>Sauvegarde</title>
</head>

<body>
	<header>
		<h1>Sauvegarde du fichier</h1> 
	</header>
	
	<div id="sav">
		<object type="image/svg+xml" data="../ExaMaker-Loic/pendrive.svg" width="120" ></object>
	<form method="get" action="sauvegarde.php">
		<p>Choisir le nom du fichier: </p> <input type="text" placeholder="Nom" name="cd" />
   		
		
		<input class="validation" type="submit" value="Sauvegarder"/>
	</form>
	
		
	
	</div>
	
	<?php

	if(isset($_GET['cd']) and trim($_GET['cd']) != '')
		$fich = $_GET['cd'];
	if(isset($_GET['cd']) and trim($_GET['cd']) != '')
	{
		$monfich = @fopen($fich.'.exam', 'w+');
		if($monfich)
		{	if(isset($_SESSION['cptexo']))
			for($a=1;$a<=$_SESSION['cptexo'];$a++)
			{						
				
				fputs($monfich,"[NUM_EXO]: ");
				fputs($monfich,"\n");
				fputs($monfich,$a);
				fputs($monfich,"\n");
				fputs($monfich,"[TITRE_EXO]: ");
				fputs($monfich,"\n");
				fputs($monfich,$_SESSION['titreExo'][$a]);
				fputs($monfich,"\n");
				
						
				for($b=1;$b<=$_SESSION['nbQuestion'][$a];$b++)
				{
					if(isset($_SESSION['ex'.$a]['num'][$b]) and isset($_SESSION['ex'.$a]['question'][$b]) and isset($_SESSION['ex'.$a]['bareme'][$b]))
					{
						fputs($monfich,"[NUM_QUESTION]:	");	
						fputs($monfich,"\n");
						fputs($monfich,$_SESSION['ex'.$a]['num'][$b]);
						fputs($monfich,"\n");
						fputs($monfich,"[QUESTION]:	");
						fputs($monfich,"\n");
						fputs($monfich,$_SESSION['ex'.$a]['question'][$b]);
						fputs($monfich,"\n");
						fputs($monfich,"[BAREME]: ");
						fputs($monfich,"\n");
						fputs($monfich,$_SESSION['ex'.$a]['bareme'][$b]);
						fputs($monfich,"\n");
						if($b < $_SESSION['nbQuestion'][$a])
						{
							fputs($monfich,"#");
							fputs($monfich,"\n");
						}  // marqueur fin de bloc question
					}	
				}	
			}
			fputs($monfich,"~"); // marqueur de fin
			if(fclose($monfich));
			else 
			{
				echo "<p>Erreur lors de la fermeture du fichier</p>";
				exit;	
			}
		}
		else 
		{
			echo "<p>Erreur lors de la creation du fichier : Chemin incorrect ou droits inexistants</p>";
			exit;	
		}
		echo '<div id="sav" class="notif">';
				echo '<br/><a href="../Creation_sujet.php" class="notif">'.'Sauvegarde effectuée vous pouvez retourner sur la page du creation du sujet en cliquant sur ce message'.'</p><br/>';
				echo '</div>';
		
	}
	?>
	</body>
</html>
