<?php session_start() ?>
<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" href="creationSujet.css" />
	<title>Création du sujet</title>
</head>

<body>
	<header>
		<h1>Création du sujet</h1> 
	</header>

	
		<div id="Boutons">		
		<div class="Ligne">
	<div class="Case">			
				<a href="intro.php?re=true" class="svg"><object type="image/svg+xml" data="Examaker-Loic/plus.svg" width="120" ></object></a>
				<h1>Nouveau Sujet</h1>
				</div>
		
		<div class="Case">			
				<a href="verification.php" class="svg"><object type="image/svg+xml" data="Examaker-Loic/modifier.svg" width="120" ></object></a>
				<h1>Modifier</h1>
				</div>
			</div>

	
		
	</div>

	<div id="Button">
	<a href="index.html">revenir à la page d'accueil</a>
	</div>

</body>
</html>
